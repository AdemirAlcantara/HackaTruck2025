//
//  Music.swift
//  Aula04_Spotify
//
//  Created by Turma02-1 on 07/07/25.
//

import SwiftUI

struct Music: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Music()
}
