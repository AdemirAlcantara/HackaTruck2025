//
//  Aula04_SpotifyApp.swift
//  Aula04_Spotify
//
//  Created by Turma02-1 on 07/07/25.
//

import SwiftUI

@main
struct Aula04_SpotifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
