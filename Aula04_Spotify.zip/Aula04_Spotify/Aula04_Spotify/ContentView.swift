//
//  ContentView.swift
//  Aula04_Spotify
//
//  Created by Turma02-1 on 07/07/25.
//

import SwiftUI

struct Musica{
    var id: Int
    var nome: String
    var artista: String
    var duracao: String
    var capa: String // url
}

struct Album{
    var id: Int
    var nome: String
    var qtdeMusicas: Int
    var imagem: String
}

struct ContentView: View {
    var img = "https://static.vecteezy.com/system/resources/previews/012/566/951/large_2x/rose-gold-glitter-background-digital-paper-photo.jpg"
    
    var Playlist = [
        Musica(id: 1, nome: "abc", artista: "adm", duracao: "2:16", capa: ""),
        Musica(id: 2, nome: "dfgh", artista: "asd", duracao: "1:58", capa: ""),
        Musica(id: 3, nome: "cvb", artista: "vsfv", duracao: "2:36", capa: ""),
        Musica(id: 4, nome: "nbhj", artista: "sdvs", duracao: "4:22", capa: ""),
        Musica(id: 5, nome: "nbgh", artista: "vsv", duracao: "2:29", capa: ""),
        Musica(id: 6, nome: "nbhjk", artista: "bsdc", duracao: "3:18", capa: ""),
        Musica(id: 7, nome: "scad", artista: "sdcj", duracao: "7:01", capa: ""),
        Musica(id: 8, nome: "jkfchj", artista: "sadfvj", duracao: "5:76", capa: ""),
        Musica(id: 9, nome: "jfhjs", artista: "sjfv", duracao: "2:59", capa: ""),
        Musica(id: 10, nome: "kjhvhj", artista: "nsnv", duracao: "3:17", capa: "")
        ]
    
    var Discoteca = [
        Album(id: 1, nome: "cadcvadv", qtdeMusicas: 16, imagem: ""),
        Album(id: 2, nome: "sfvasfv", qtdeMusicas: 28, imagem: ""),
        Album(id: 3, nome: "sdfv", qtdeMusicas: 10, imagem: ""),
        Album(id: 4, nome: "sfvfv", qtdeMusicas: 19, imagem: ""),
        Album(id: 5, nome: "safv", qtdeMusicas: 3, imagem: "")
    ]
    
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(
                    gradient: Gradient(colors: [.salmão, .black]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                ScrollView{
                    VStack{
                        Spacer()
                        VStack{
                            AsyncImage(url: URL(string: img)) { image in
                                   image
                                    .resizable()
                                    .aspectRatio(1/1, contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                                    .frame(width: 160, height: 160)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(.leve, lineWidth: 5))
                                    .cornerRadius(20)
                                    .shadow(radius: 15)
                               } placeholder: {
                                   Image(systemName: "photo.fill")
                                       .foregroundColor(.white)
                                       .frame(width: 160, height: 160)
                                       .border(Color.white)
                               }
                        }
                        .frame(width: 250, height: 250)
                        .padding()
                        Spacer()
                        NavigationLink(destination: ContentView()){
                            VStack{
                                ForEach(Playlist, id: \.id){ i in
                                    HStack{
                                        AsyncImage(url: URL(string: i.capa)) { image in
                                               image.resizable()
                                                    .aspectRatio(contentMode: .fit)
                                           } placeholder: {
                                               Image(systemName: "photo.fill")
                                                   .foregroundColor(.white)
                                                   .frame(width: 25, height: 25)
                                                   .border(Color.white)
                                           }
                                           .frame(width: 30, height: 30)
                                        Spacer()
                                        VStack{
                                            Text(i.nome)
                                                .foregroundColor(.white)
                                                .font(.title2)
                                                .bold()
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                            Text(i.artista)
                                                .foregroundColor(.white)
                                                .font(.subheadline)
                                                .bold()
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                        }
                                        Spacer()
                                        Text(i.duracao)
                                            .foregroundColor(.white)
                                            .font(.title3)
                                            .bold()
                                    }
                                }
                                .padding()
                                .frame(width: 350, height: 70)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(.leve, lineWidth: 5))
                                .cornerRadius(20)
                            }
                        }
                    }
                    .padding()
                    Spacer()
                    ScrollView(.horizontal){
                        HStack{
                            ForEach(Discoteca, id: \.id){ i in
                                AsyncImage(url: URL(string: i.imagem)) { image in
                                       image.resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 160, height: 160)
                                   } placeholder: {
                                       Image(systemName: "photo.fill")
                                           .foregroundColor(.white)
                                           .frame(width: 160, height: 160)
                                           .border(Color.white)
                                   }
                            }
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
