//
//  Musica.swift
//  Aula04_Spotify
//
//  Created by Turma02-1 on 07/07/25.
//

import SwiftUI

struct Musica: View {
    var body: some View {
        
    }
}

#Preview {
    Musica()
}
