//
//  Model.swift
//  IoT
//
//  Created by Turma02-1 on 21/07/25.
//

import Foundation

struct Umidade: Codable, Hashable {
    let dado: String
    
    enum CodingKeys: String, CodingKey{
        case dado = "0"
    }
}

class ViewModel: ObservableObject {
    @Published var dados: [Umidade] = []
    func fetch() {
        guard let url = URL(string: "http://192.168.128.12:1880/leituraIOT") else {
            return
        }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do{
                let parsed = try JSONDecoder().decode([Umidade].self, from: data)
                DispatchQueue.main.async{
                    self?.dados = parsed
                }
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
}
