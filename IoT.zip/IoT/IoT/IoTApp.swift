//
//  IoTApp.swift
//  IoT
//
//  Created by Turma02-1 on 21/07/25.
//

import SwiftUI

@main
struct IoTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
