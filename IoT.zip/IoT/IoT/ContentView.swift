//
//  ContentView.swift
//  Aula06_API
//
//  Created by Turma02-1 on 14/07/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        List(viewModel.dados, id: \.dado){ umi in
            HStack{
                Text("Umidade")
                    .frame(alignment: .leading)
                    .foregroundColor(.black)
                    .font(.title)
                    .bold()
                Spacer()
                Text(umi.dado)
                    .frame(width: 150, height: 80)
                    .background(.drop)
                    .foregroundColor(.black)
                    .font(.title)
                    .bold()
                
                
            }
        }
        .navigationTitle("Resultados")
        .onAppear(){
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
