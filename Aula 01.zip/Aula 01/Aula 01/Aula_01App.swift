//
//  Aula_01App.swift
//  Aula 01
//
//  Created by Turma02-1 on 02/07/25.
//

import SwiftUI

@main
struct Aula_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            Desafio_01()
            Desafio_02()
        }
    }
}
