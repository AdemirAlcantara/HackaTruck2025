//
//  Desafio 02.swift
//  Aula 01
//
//  Created by Turma02-1 on 02/07/25.
//

import SwiftUI

struct Desafio_02: View {
    var body: some View {
        VStack(content: {
            Spacer()
            HStack(spacing: 10, content: {
                Image("swift-og-1")
                    .resizable()
                    .frame(width: 100, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .padding()
                VStack(content: {
                    Text("Swift")
                    Text("Xcode")
                    Text("iOS App")
                })
                .padding()
            })
            Spacer()

            .padding()
        })
        .padding()
    }
}

#Preview {
    Desafio_02()
}
