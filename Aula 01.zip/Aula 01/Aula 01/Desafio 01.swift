//
//  ContentView.swift
//  Aula 01
//
//  Created by Turma02-1 on 02/07/25.
//

import SwiftUI

struct Desafio_01: View {
    var body: some View {
        VStack {
            HStack(content: {
                Rectangle()
                    .fill(.blue)
                    .frame(width: 80, height:80)
                    
                Spacer()
                Rectangle()
                    .fill(.yellow)
                    .frame(width: 80, height:80)
            })
            Spacer()
            HStack(content: {
                Rectangle()
                    .fill(.red)
                    .frame(width: 80, height:80)
                Spacer()
                Rectangle()
                    .fill(.green)
                    .frame(width: 80, height:80)
            })
        }
        .padding()
    }
}

#Preview {
    Desafio_01()
}
