//
//  DesafioPrincipal.swift
//  Aula 01
//
//  Created by Turma02-1 on 02/07/25.
//

import SwiftUI

struct DesafioPrincipal: View {
    @State private var text = ""
    @State private var showingAlert = false
    var body: some View {
        ZStack{
            Image("CampusI")
                .resizable()
                .opacity(0.2)
                .ignoresSafeArea()
            VStack{
                VStack{
                    Text("Bem  vindo,  "+text)
                        .padding()
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                        .foregroundColor(.green)
                    TextField("Digite aqui...", text: $text, axis: .vertical)
                        .frame(width: 200, height: 100)
                        .textFieldStyle(.roundedBorder)
                        .shadow(radius: 5)
                }
                Spacer()
                HStack{
                    Image("Fipp")
                        .resizable()
                        .frame(width: 258, height: 150)
                        .zIndex(1)
                }
                Spacer()
                HStack{
                    Button("Surpresinha") {
                                showingAlert = true
                            }
                            .alert(isPresented: $showingAlert) {
                                Alert(
                                    title: Text("ATENÇÃO"),
                                    message: Text("100% de Horas Complementares"),
                                    dismissButton: .default(Text("VAMOOOOOO"))
                                )
                            }
                }
                .padding()
            }
        }
    }
}

#Preview {
    DesafioPrincipal()
}
