//
//  ContentView.swift
//  Aula08_coreML
//
//  Created by Turma02-1 on 17/07/25.
//

import SwiftUI
import CoreML

struct ContentView: View {
    @State private var prediction: String = "Classificando..."
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Classificação com MobileNetV2")
                .font(.title)
                .bold()
            
            Image("elefante") // Nome da imagem no Assets.xcassets
                .resizable()
                .frame(width: 250, height: 250)
                .scaledToFill()
                .border(Color.gray, width: 2)
            
            Text(prediction)
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding()
        }
        .onAppear {
            classifyImage()
        }
        .padding()
    }
    
    func classifyImage() {
        guard let uiImage = UIImage(named: "elefante") else {
            prediction = "Erro: imagem não encontrada no Assets"
            return
        }
        
        // Redimensiona para 224x224 (MobileNetV2 espera esse tamanho)
        let resized = uiImage.resize(to: CGSize(width: 224, height: 224))
        
        guard let buffer = resized.toCVPixelBuffer() else {
            prediction = "Erro ao converter imagem"
            return
        }
        
        do {
            let model = try MobileNetV2(configuration: MLModelConfiguration())
            let input = MobileNetV2Input(image: buffer)
            let result = try model.prediction(input: input)
            
            // Mostra a classe mais provável e a probabilidade
            if let top = result.classLabelProbs.max(by: { $0.value < $1.value }) {
                prediction = "Classe: \(top.key)\nConfiança: \(String(format: "%.2f", top.value * 100))%"
            } else {
                prediction = "Não foi possível classificar"
            }
        } catch {
            prediction = "Erro: \(error.localizedDescription)"
        }
    }
}

// MARK: - Extensões para Redimensionar e Converter
extension UIImage {
    func resize(to size: CGSize) -> UIImage {
        UIGraphicsBeginImageContext(size)
        self.draw(in: CGRect(origin: .zero, size: size))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
    
    func toCVPixelBuffer() -> CVPixelBuffer? {
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                     kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(self.size.width),
                                         Int(self.size.height),
                                         kCVPixelFormatType_32ARGB,
                                         attrs,
                                         &pixelBuffer)
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else { return nil }
        
        CVPixelBufferLockBaseAddress(buffer, [])
        let context = CGContext(data: CVPixelBufferGetBaseAddress(buffer),
                                width: Int(self.size.width),
                                height: Int(self.size.height),
                                bitsPerComponent: 8,
                                bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)
        context?.translateBy(x: 0, y: self.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context!)
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(buffer, [])
        
        return buffer
    }
}


#Preview {
    ContentView()
}
