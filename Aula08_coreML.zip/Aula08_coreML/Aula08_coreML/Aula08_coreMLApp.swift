//
//  Aula08_coreMLApp.swift
//  Aula08_coreML
//
//  Created by Turma02-1 on 17/07/25.
//

import SwiftUI

@main
struct Aula08_coreMLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
