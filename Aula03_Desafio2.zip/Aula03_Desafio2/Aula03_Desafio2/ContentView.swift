//
//  ContentView.swift
//  Aula03_Desafio2
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            ZStack{
                Color.default
                    .ignoresSafeArea()
                VStack{
                    VStack{
                        Text("Desafio")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .bold()
                        Image(systemName: "2.circle")
                            .resizable()
                            .frame(width: 50, height: 50)
                    }
                    .frame(width: 150, height: 130)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(.black, lineWidth: 4))
                    .padding()
                    Spacer()
                    NavigationLink(destination: Modulo1()){
                        Text("Modo 1")
                            .font(.title3)
                            .bold()
                            .frame(width: 120, height: 70)
                            .background(.black)
                            .foregroundColor(.default)
                            .cornerRadius(10)
                            .padding()
                    }
                    NavigationLink(destination: Modulo2()){
                        Text("Modo 2")
                            .font(.title3)
                            .bold()
                            .frame(width: 120, height: 70)
                            .background(.black)
                            .foregroundColor(.default)
                            .cornerRadius(10)
                            .padding()
                    }
                    Button("Modo 3"){
                        
                    }
                    .font(.title3)
                    .bold()
                    .frame(width: 120, height: 70)
                    .background(.black)
                    .foregroundColor(.default)
                    .cornerRadius(10)
                    .padding()
                    Spacer()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
