//
//  Aula03_Desafio2App.swift
//  Aula03_Desafio2
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

@main
struct Aula03_Desafio2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
