//
//  Modulo3.swift
//  Aula03_Desafio2
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct Modulo3: View {
    @State var nome: String = ""
    var body: some View {
        ZStack{
            Color.default
                .ignoresSafeArea()
            VStack{
                Text("Modo 3")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(.black, lineWidth: 3))
                Spacer()
                VStack{
                    Text("Volte \(nome)!")
                        .font(.title3)
                        .bold()
                        .padding()
                }
                .frame(width: 250, height: 150)
                .background(.black)
                .foregroundColor(.default)
                .cornerRadius(20)
                .padding()
                Spacer()
            }
        }
    }
}

#Preview {
    Modulo3()
}
