//
//  Modulo2.swift
//  Aula03_Desafio2
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct Modulo2: View {
    @State var nome = ""
    var body: some View {
        NavigationStack{
            ZStack{
                Color.default
                    .ignoresSafeArea()
                VStack{
                    Text("Modo 2")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .bold()
                        .padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(.black, lineWidth: 3))
                    Spacer()
                    VStack{
                        Spacer()
                        TextField("Seu Nome", text: $nome)
                            .multilineTextAlignment(.center)
                        Spacer()
                        Text("Bem Vindo, \(nome)")
                            .font(.title3)
                            .bold()
                        Spacer()
                        NavigationLink(destination: Modulo3(nome: nome)){
                            Text("Modo 3")
                                .font(.title3)
                                .bold()
                                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 50)
                                .foregroundColor(.default)
                                .background(.black)
                        }
                        .frame(width: 100, height: 40)
                        .cornerRadius(10)
                        Spacer()
                    }
                    .frame(width: 250, height: 150)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(.black, lineWidth: 10))
                    .cornerRadius(20)
                    Spacer()
                }
            }
        }
    }
}

#Preview {
    Modulo2()
}
