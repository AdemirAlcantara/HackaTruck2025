//
//  Modulo1.swift
//  Aula03_Desafio2
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct Modulo1: View {
    var body: some View {
        ZStack{
            Color.default
                .ignoresSafeArea()
            VStack{
                Text("Modo 1")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .bold()
                    .padding()
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(.black, lineWidth: 3))
                Spacer()
                VStack{
                    Text("Nome: Ademir")
                        .font(.title3)
                        .bold()
                        .padding()
                    Text("Sobrenome: Alcântara")
                        .font(.title3)
                        .bold()
                        .padding()
                }
                .frame(width: 250, height: 200)
                .background(.black)
                .foregroundColor(.default)
                .cornerRadius(20)
                .padding()
                Spacer()
            }
        }
    }
}

#Preview {
    Modulo1()
}
