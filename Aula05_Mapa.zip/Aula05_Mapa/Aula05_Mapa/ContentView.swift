//
//  ContentView.swift
//  Aula05_Mapa
//
//  Created by Turma02-1 on 08/07/25.
//

import SwiftUI
import MapKit

struct Location: Hashable {
    let nome: String
    let foto: String
    let bandeira: String
    let populacao: Int
    let latitude: Double
    let longitude: Double
}

struct ContentView: View {
//    @State private var lat:Double
//    
//    @State private var long:Double
    
    @State private var pos = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -22.079, longitude: -51.472),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
        )
    
    @State var regiaoselect = Location(nome: "Álvares Machado", foto: "https://upload.wikimedia.org/wikipedia/commons/2/25/Santu%C3%A1rio_Morada_de_Deus.JPG", bandeira: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ed/Bandeira_de_%C3%81lvares_Machado.jpg/640px-Bandeira_de_%C3%81lvares_Machado.jpg", populacao: 27255, latitude: -22.079, longitude: -51.472)
    
    @State private var regiao = [
        Location(nome: "Presidente Prudente", foto: "https://www.imobiliariariobranco.com.br/wp-content/uploads/2024/09/bairros-de-presidente-prudente.jpg", bandeira: "https://hinomp3.com/wp-content/uploads/2018/08/hino-de-presidente-prudente-download-mp3-online.jpg", populacao: 231953, latitude: -22.12126, longitude: -51.40917),
        
        Location(nome: "Dracena", foto: "https://s2-redeglobo.glbimg.com/K3I2SUtDax3YJga0_WPylTXpZlA=/427x240/s02.video.glbimg.com/deo/vi/37/81/11188137", bandeira: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Bandeira_Dracena_SaoPaulo_Brasil.svg/1200px-Bandeira_Dracena_SaoPaulo_Brasil.svg.png", populacao: 47287, latitude: -21.483, longitude: -51.533),
        
        Location(nome: "Presidente Epitácio", foto: "https://viagemeturismo.abril.com.br/wp-content/uploads/2016/12/presidente-epitacio-a-praia-que-nao-fica-no-litoral-foto-gesp_201004150007.jpeg", bandeira: "https://upload.wikimedia.org/wikipedia/commons/5/53/Bandeira_de_Presidente_Epit%C3%A1cio.jpg", populacao: 44572, latitude: -21.7825, longitude: -52.120983),
        
        Location(nome: "Presidente Venceslau", foto: "https://www.guiadoturismobrasil.com/up/img/1442705481.jpg", bandeira: "https://www.presidentevenceslau.sp.gov.br/scripts/kcfinder/upload/images/municipio/bandeira.png", populacao: 39648, latitude:  -21.8887, longitude: -51.8306),
        
        Location(nome: "Adamantina", foto: "https://media.staticontent.com/media/pictures/b6bffb49-fce7-4a84-b7eb-d8482c3200a9", bandeira: "https://upload.wikimedia.org/wikipedia/commons/d/d3/Bandeira_Adamantina.jpg", populacao: 35153, latitude: -21.6756, longitude: -51.063),
        
        Location(nome: "Álvares Machado", foto: "https://upload.wikimedia.org/wikipedia/commons/2/25/Santu%C3%A1rio_Morada_de_Deus.JPG", bandeira: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ed/Bandeira_de_%C3%81lvares_Machado.jpg/640px-Bandeira_de_%C3%81lvares_Machado.jpg", populacao: 27255, latitude: -22.079, longitude: -51.472)
        ]
        
    var body: some View {
        ZStack{
                VStack{
                    Map(position: $pos){
                        ForEach(regiao, id: \.self) { i in
                            Annotation(i.nome, coordinate: CLLocationCoordinate2D(latitude: i.latitude, longitude: i.longitude)) {
                                Image(systemName: "mappin.circle")
                                    .resizable()
                                    .foregroundStyle(.blue)
                                    .frame(width: 50, height: 50)
                            }
                        }
                    }
                    Spacer()
                    Picker("Escolha a Cidade", selection: $regiaoselect){
                        ForEach(regiao, id: \.self) { i in
                            Text(i.nome)
                        }
                    }
                    .onChange(of: regiaoselect){ abc in
                        pos = MapCameraPosition.region(
                            MKCoordinateRegion(
                                center: CLLocationCoordinate2D(latitude: abc.latitude, longitude: abc.longitude),
                                span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
                        )
                    }
                    .frame(width: 250, height: 50, alignment: .center)
                    .background(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(.blue, lineWidth: 5))
                    .cornerRadius(20)
                    .padding()
                    Spacer()
                    Text("Teste")
                        .padding()
                }
            }
        }
    }

#Preview {
    ContentView()
}
