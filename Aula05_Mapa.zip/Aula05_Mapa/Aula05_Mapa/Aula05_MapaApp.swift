//
//  Aula05_MapaApp.swift
//  Aula05_Mapa
//
//  Created by Turma02-1 on 08/07/25.
//

import SwiftUI

@main
struct Aula05_MapaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
