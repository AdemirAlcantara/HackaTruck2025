//
//  Aula06_APIApp.swift
//  Aula06_API
//
//  Created by Turma02-1 on 14/07/25.
//

import SwiftUI

@main
struct Aula06_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
