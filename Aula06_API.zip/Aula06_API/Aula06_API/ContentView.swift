//
//  ContentView.swift
//  Aula06_API
//
//  Created by Turma02-1 on 14/07/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        List(viewModel.personagens){ nomes in
            HStack{
                AsyncImage(url: URL(string: nomes.image!)) { image in
                       image.resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipShape(Circle())
                        .frame(width: 80, height: 80)
                        .shadow(radius: 10)
                   } placeholder: {
                       Image(systemName: "photo.fill")
                           .aspectRatio(contentMode: .fill)
                           .clipShape(Circle())
                           .frame(width: 80, height: 80)
                           .overlay(){
                               Circle()
                                   .stroke(.black)
                           }
                           .shadow(radius: 10)
                   }
                   .padding()
                Text(nomes.name!)
                    .foregroundColor(.black)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            }
        }
        .onAppear(){
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
