//
//  Aula07_MinhaAPIApp.swift
//  Aula07_MinhaAPI
//
//  Created by Turma02-1 on 16/07/25.
//

import SwiftUI

@main
struct Aula07_MinhaAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
