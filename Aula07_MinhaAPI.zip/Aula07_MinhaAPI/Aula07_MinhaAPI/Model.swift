//
//  Model.swift
//  Aula07_MinhaAPI
//
//  Created by Turma02-1 on 16/07/25.
//

import Foundation

struct Carro: Decodable, Hashable {
    let modelo:String?
    let marca:String?
    let imagem:String?
}

class ViewModel: ObservableObject {
    @Published var carros: [Carro] = []
    func fetch() {
        guard let url = URL(string: "http://127.0.0.1:1880/leituraADM") else {
            return
        }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do{
                let parsed = try JSONDecoder().decode([Carro].self, from: data)
                DispatchQueue.main.async{
                    self?.carros = parsed
                }
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
}
