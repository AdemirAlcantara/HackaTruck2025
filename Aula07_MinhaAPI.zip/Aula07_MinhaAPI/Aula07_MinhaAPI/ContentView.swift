//
//  ContentView.swift
//  Aula07_MinhaAPI
//
//  Created by Turma02-1 on 16/07/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        VStack{
            Text("Caro")
            List(viewModel.carros, id: \.self){ carro in
                HStack{
                    AsyncImage(url: URL(string: carro.imagem!)) { image in
                           image.resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 80, height: 80)
                            .shadow(radius: 10)
                       } placeholder: {
                           Image(systemName: "photo.fill")
                               .aspectRatio(contentMode: .fill)
                               .clipShape(Circle())
                               .frame(width: 80, height: 80)
                               .overlay(){
                                   Circle()
                                       .stroke(.black)
                               }
                               .shadow(radius: 10)
                       }
                       .padding()
                    VStack{
                        Text(carro.marca!)
                            .foregroundColor(.black)
                            .font(.title2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Text(carro.modelo!)
                            .foregroundColor(.black)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    
                }
            }
            .onAppear(){
                viewModel.fetch()
            }
        }
        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
        .bold()
    }
}

#Preview {
    ContentView()
}
