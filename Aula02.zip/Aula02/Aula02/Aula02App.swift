//
//  Aula02App.swift
//  Aula02
//
//  Created by Turma02-1 on 03/07/25.
//

import SwiftUI

@main
struct Aula02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
