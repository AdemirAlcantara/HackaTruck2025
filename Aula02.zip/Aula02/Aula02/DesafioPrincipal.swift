//
//  DesafioPrincipal.swift
//  Aula02
//
//  Created by Turma02-1 on 03/07/25.
//

import SwiftUI

struct DesafioPrincipal: View {
    @State private var dist:Float = 0
    @State private var tempo:Float = 0
    @State private var veloc:Float = 0
    @State private var botao = false
    @State private var imagem = "default"
    @State private var cor:Color = .background
    var body: some View {
        ZStack{
            cor
                .ignoresSafeArea()
            VStack{
                VStack{
                    VStack{
                        Text("Digite a Distância (km):")
                            .bold()
                        TextField("", value: $dist, format: .number)
                            .keyboardType(.decimalPad)
                            .textContentType(.oneTimeCode)
                            .padding()
                            .frame(width: 100, height: 50)
                            .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/)
                            .cornerRadius(3)
                            .bold()
                    }
                    .padding()
                    Spacer()
                    VStack{
                        Text("Digite o Tempo (h):")
                            .bold()
                        TextField("", value: $tempo, format: .number)
                            .keyboardType(.decimalPad)
                            .textContentType(.oneTimeCode)
                            .padding()
                            .frame(width: 100, height: 50)
                            .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/)
                            .cornerRadius(3)
                            .bold()
                    }
                    .padding()
                    Spacer()
                    VStack{
                        Button("Calcular") {
                            veloc = dist / tempo
                            switch veloc {
                                case 0..<10:
                                cor = .tartaruga
                                imagem = "tartaruga"
                                case 10..<30:
                                cor = .elefante
                                imagem = "elefante"
                                case 30..<70:
                                cor = .avestruz
                                imagem = "avestruz"
                                case 70..<90:
                                cor = .leão
                                imagem = "leão"
                                case 90...130:
                                cor = .guepardo
                                imagem = "guepardo"
                                default:
                                cor = .background
                                imagem = "default"
                            }
                        }
                        .padding()
                        .background(.black)
                        .foregroundColor(.white)
                        .bold()
                        .cornerRadius(10)
                        HStack{
                            Text("Velocidade: ")
                            Text(veloc, format: .number.precision(.fractionLength(2)))
                            Text("km/h")
                        }
                        .frame(width: 250, height: 50)
                        .border(Color.background)
                        .background(.black)
                        .cornerRadius(15)
                        .foregroundColor(cor)
                        .bold()
                    }
                }
                .padding()
                Spacer()
                    VStack{
                        Image(imagem)
                            .resizable()
                            .aspectRatio(1/1, contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                            .frame(width: 200, height: 200)
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .shadow(radius: 20)
                    }
                    .padding()
                    Spacer()
                VStack{
                    HStack{
                        Text("Animal")
                        Text("Vel. (km)")
                        Text("Cor")
                    }
                    .foregroundColor(.white)
                    .bold()
                    HStack{
                        VStack{
                            Text("Tartaruga")
                            Text("Elefante")
                            Text("Avestruz")
                            Text("Leão")
                            Text("Guepardo")
                        }
                        .foregroundColor(.white)
                        .bold()
                        VStack{
                            Text("0 - 9,9")
                            Text("10 - 29,9")
                            Text("30 - 69,9")
                            Text("70 - 89,9")
                            Text("90 - 130")
                        }
                        .foregroundColor(.white)
                        .bold()
                        VStack{
                            Circle()
                                .frame(width: 15, height: 15)
                                .foregroundColor(.tartaruga)
                            Circle()
                                .frame(width: 15, height: 15)
                                .foregroundColor(.elefante)
                            Circle()
                                .frame(width: 15, height: 15)
                                .foregroundColor(.avestruz)
                            Circle()
                                .frame(width: 15, height: 15)
                                .foregroundColor(.leão)
                            Circle()
                                .frame(width: 15, height: 15)
                                .foregroundColor(.guepardo)
                        }
                    }
                }
                .padding()
                .background(.black)
                .cornerRadius(10)
                Spacer()
            }
        }
    }
}

#Preview {
    DesafioPrincipal()
}
