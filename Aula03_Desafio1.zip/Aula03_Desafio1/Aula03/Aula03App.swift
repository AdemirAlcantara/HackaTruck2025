//
//  Aula03App.swift
//  Aula03
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

@main
struct Aula03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
