//
//  ContentView.swift
//  Aula03
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            TabView{
                Tela01()
                    .tabItem{
                        Label("First", systemImage: "1.square")
                    }
                Tela02()
                    .tabItem{
                        Label("Second", systemImage: "2.square")
                    }
                Tela03()
                    .tabItem{
                        Label("Third", systemImage: "3.square")
                    }
                Tela04()
                    .tabItem{
                        Label("List", systemImage: "list.bullet.circle.fill")
                    }
            }
        }
    }
}

#Preview {
    ContentView()
}
