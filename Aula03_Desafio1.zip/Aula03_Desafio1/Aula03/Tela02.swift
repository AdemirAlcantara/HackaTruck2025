//
//  Tela02.swift
//  Aula03
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct Tela02: View {
    var body: some View {
        ZStack{
            Color.silver
                .ignoresSafeArea(.container, edges: .top)
            VStack {
                Image(systemName: "2.circle")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .aspectRatio(1/1, contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                    .foregroundStyle(.black)
            }
            .padding()
        }
    }
}

#Preview {
    Tela02()
}
