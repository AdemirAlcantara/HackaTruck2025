//
//  Tela04.swift
//  Aula03
//
//  Created by Turma02-1 on 04/07/25.
//

import SwiftUI

struct Tela04: View {
    var body: some View {
        NavigationStack{
            List{
                HStack{
                    Text("First")
                        .font(.title3)
                        .bold()
                    Spacer()
                    Image(systemName: "1.circle")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.gold)
                }
                .padding()
                HStack{
                    Text("Second")
                        .font(.title3)
                        .bold()
                    Spacer()
                    Image(systemName: "2.circle")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.silver)
                }
                .padding()
                HStack{
                    Text("Third")
                        .font(.title3)
                        .bold()
                    Spacer()
                    Image(systemName: "3.circle")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.bronze)
                }
                .padding()
            }
            .navigationTitle("List")
        }
    }
}

#Preview {
    Tela04()
}
