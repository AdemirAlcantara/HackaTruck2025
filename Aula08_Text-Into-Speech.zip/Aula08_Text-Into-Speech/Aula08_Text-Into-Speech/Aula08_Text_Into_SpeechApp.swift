//
//  Aula08_Text_Into_SpeechApp.swift
//  Aula08_Text-Into-Speech
//
//  Created by Turma02-1 on 17/07/25.
//

import SwiftUI

@main
struct Aula08_Text_Into_SpeechApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
